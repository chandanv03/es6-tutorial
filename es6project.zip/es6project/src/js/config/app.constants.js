const AppConstants = {
  api: 'https://conduit.productionready.io/api',
  // api: 'http://localhost:3000/api',
  jwtKey: 'jwtToken',
  appName: 'Conduit',
};

export default AppConstants;
