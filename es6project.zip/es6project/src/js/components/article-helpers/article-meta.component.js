let ArticleMeta= {
  bindings: {
    article: '='
  },
  transclude: true,
  templateUrl: 'components/article-helpers/article-meta.html'
};

export default ArticleMeta;
